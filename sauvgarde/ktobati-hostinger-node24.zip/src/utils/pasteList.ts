import type { BookFileType } from '../data/types';

/**
 * Parse a pasted list of the admin's Up-4ever files into metadata-only items.
 * Accepts HTML anchors (`<a href="…">name - size</a>`) or plain lines
 * (`https://www.up-4ever.net/slug - name.pdf - 7.3 MB`).
 * PDF/EPUB only — other types (or lines without a usable name/URL) are skipped.
 * The share URL is kept verbatim as the manual download link; file bytes are
 * never fetched. `file_code` = URL slug (matches the API's file_code, so
 * dedupe also works against a later API sync).
 */

export interface PastedFile {
  file_code: string;
  name: string;
  link: string;
  ext: BookFileType;
  size?: number;
  folder: string;
}

export interface PasteParseResult {
  items: PastedFile[];
  skipped: number;
  duplicates: number;
}

const UP4_URL = /https?:\/\/(?:www\.)?up-4ever\.net\/[A-Za-z0-9]+\/?/i;
const SIZE_SUFFIX = /\s*[-–—]\s*\d+(?:\.\d+)?\s*(?:MB|KB|GB|MO|KO|GO)\s*$/i;
const SIZE_BYTES: Record<string, number> = {
  KB: 1024, MB: 1024 ** 2, GB: 1024 ** 3,
  KO: 1024, MO: 1024 ** 2, GO: 1024 ** 3,
};

function sizeOf(label: string): number | undefined {
  const m = /(\d+(?:\.\d+)?)\s*(KB|MB|GB|KO|MO|GO)\b/i.exec(label);
  if (!m) return undefined;
  return Math.round(parseFloat(m[1]) * SIZE_BYTES[m[2].toUpperCase()]);
}

function extOf(name: string): BookFileType | null {
  if (/\.pdf$/i.test(name)) return 'pdf';
  if (/\.epub$/i.test(name)) return 'epub';
  return null;
}

export function parsePastedFileList(text: string): PasteParseResult {
  const byCode = new Map<string, PastedFile>();
  let skipped = 0;
  let duplicates = 0;

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) continue;

    // 1) share URL: href="…" first, else any bare up-4ever link in the line
    const href = /href\s*=\s*["']([^"']+)["']/i.exec(line)?.[1] ?? UP4_URL.exec(line)?.[0] ?? '';
    if (!href || !UP4_URL.test(href)) { skipped++; continue; }

    // 2) label: HTML text between > and <, else the text after the URL
    const label = />\s*([^<]+?)\s*</.exec(line)?.[1] ?? line.split(/https?:\/\/\S+/i)[1] ?? '';
    const name = label.replace(/^[\s\-–—:|]+/, '').replace(SIZE_SUFFIX, '').trim();
    const ext = extOf(name);
    if (!ext) { skipped++; continue; }

    let slug = '';
    try {
      const u = new URL(href);
      slug = u.pathname.split('/').filter(Boolean).pop() ?? '';
    } catch {
      skipped++;
      continue;
    }
    if (!slug) { skipped++; continue; }

    if (byCode.has(slug)) { duplicates++; continue; }
    const size = sizeOf(label);
    byCode.set(slug, {
      file_code: slug,
      name,
      link: href.replace(/\/+$/, ''),
      ext,
      size,
      folder: '',
    });
  }

  return { items: [...byCode.values()], skipped, duplicates };
}
