import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowRight, RefreshCw, Loader2, Upload, CheckCircle2, AlertTriangle, Search, Lock, FolderTree, ExternalLink } from 'lucide-react';
import { useAdminLibrary } from '../../store/useLibrary';
import { useAdminPath } from '../base';
import { useToast } from '../Toast';
import { slugify, normalizeAr } from '../../store/derive';
import { parsePastedFileList } from '../../utils/pasteList';
import { humanLanguage } from './BookForm';
import type { BookRecord, BookFile, BookFileType } from '../../data/types';

/** One PDF/EPUB file from the admin's Up-4ever account (metadata + share link only). */
interface SyncFile {
  file_code: string;
  name: string;
  link: string;
  ext: BookFileType;
  size?: number;
  uploaded?: string;
  fld_id?: number | string;
  folder?: string;
}

interface EnrichData {
  title?: string;
  author?: string;
  year?: string;
  language?: string;
  isbn?: string;
  description?: string;
  coverUrl?: string;
}
type EnrichState =
  | { phase: 'idle' }
  | { phase: 'loading' }
  | { phase: 'done'; data: EnrichData }
  | { phase: 'nomatch' }
  | { phase: 'failed'; message?: string };

interface RowState {
  checked: boolean;
  title: string;
  enrich: EnrichState;
}

/* ---- conservative metadata matching (only reliable matches are applied) ---- */
function prepMatch(s: string): string {
  const cleaned = s
    .replace(/\.[A-Za-z0-9]{2,5}$/, '') // extension
    .replace(/[_\-.]+/g, ' ')
    .replace(/\b(pdf|epub|retail|book)\b/gi, ' ')
    .replace(/\b(19|20)\d{2}\b/g, ' ');
  return normalizeAr(cleaned).replace(/[^\p{L}\p{N} ]/gu, ' ').replace(/\s+/g, ' ').trim();
}
function dice(a: string, b: string): number {
  if (a === b) return 1;
  if (a.length < 2 || b.length < 2) return 0;
  const grams = new Map<string, number>();
  for (let i = 0; i < a.length - 1; i++) {
    const g = a.slice(i, i + 2);
    grams.set(g, (grams.get(g) ?? 0) + 1);
  }
  let hits = 0;
  for (let i = 0; i < b.length - 1; i++) {
    const g = b.slice(i, i + 2);
    const n = grams.get(g) ?? 0;
    if (n > 0) { hits++; grams.set(g, n - 1); }
  }
  return (2 * hits) / (a.length - 1 + b.length - 1);
}
function reliableMatch(filenameBase: string, metaTitle: string): boolean {
  const A = prepMatch(filenameBase);
  const B = prepMatch(metaTitle);
  if (A.length < 6 || B.length < 6) return false;
  if (A === B) return true;
  if (A.includes(B) || B.includes(A)) return Math.min(A.length, B.length) >= 8;
  return dice(A, B) >= 0.66;
}

function titleFromName(name: string): string {
  return name.replace(/\.(pdf|epub)$/i, '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim() || name;
}

function errMessage(status: number, data: { error?: string } | null): string {
  switch (data?.error) {
    case 'auth_not_configured':
      return 'مصادقة المزامنة غير مُهيّأة على الخادم. أضِف ADMIN_SYNC_EMAIL و ADMIN_SYNC_PASSWORD في بيئة الخادم (نيم .env.local للتطوير) ثم أعد المحاولة.';
    case 'missing_api_key':
      return 'المفتاح UP4EVER_API_KEY غير مضبوط على الخادم. اطلب مفتاح API في حسابك بصلاحية files_read وfolders وأكِّده في Up-4ever، ثم أضِفه في بيئة الخادم — لا تلصقه في المحادثة أو الكود أو المتصفح.';
    case 'up4ever_rejected':
      return 'رفض Up-4ever المفتاح: تأكد أن المفتاح معتمد وأن صلاحيتي files_read وfolders مُفعّلتان.';
    case 'up4ever_rate_limited':
      return 'تجاوزت حد الطلبات لدى Up-4ever — انتظر قليلًا ثم أعد الجلب.';
    case 'up4ever_unavailable':
      return 'تعذّر الوصول إلى Up-4ever من الخادم الآن — حاول لاحقًا.';
    case 'invalid_credentials':
      return 'بيانات الدخول غير صحيحة.';
    case 'unauthorized':
      return 'انتهت جلسة المزامنة — سجّل الدخول مرة أخرى.';
    default:
      return status >= 500 ? 'خطأ في الخادم — حاول مرة أخرى.' : 'تعذّر تنفيذ الطلب.';
  }
}

export default function Up4everSync() {
  const { snap, store } = useAdminLibrary();
  const path = useAdminPath();
  const { toast } = useToast();

  const [needLogin, setNeedLogin] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [loggingIn, setLoggingIn] = useState(false);
  const [loginError, setLoginError] = useState('');

  const [fetching, setFetching] = useState(false);
  const [fetchError, setFetchError] = useState('');
  const [items, setItems] = useState<SyncFile[]>([]);
  const [stats, setStats] = useState<{ filesTotal?: number; pages?: number; folders?: number; excluded?: number; found?: number } | null>(null);
  const [rows, setRows] = useState<Record<string, RowState>>({});
  const [importing, setImporting] = useState(false);
  const [imported, setImported] = useState<Set<string>>(new Set());

  // Google sign-in (server-configured; button only when enabled)
  const [googleOn, setGoogleOn] = useState<boolean | null>(null);
  const [notice, setNotice] = useState('');
  const [searchParams] = useSearchParams();
  const handledGoogle = useRef(false);

  useEffect(() => {
    let alive = true;
    fetch('/api/admin/google/status', { credentials: 'same-origin' })
      .then((r) => r.json())
      .then((d: { configured?: boolean }) => { if (alive) setGoogleOn(Boolean(d?.configured)); })
      .catch(() => { if (alive) setGoogleOn(false); });
    return () => { alive = false; };
  }, []);

  // handle return from /api/admin/google/start → callback redirect (?google=…)
  useEffect(() => {
    if (handledGoogle.current) return;
    handledGoogle.current = true;
    const g = searchParams.get('google');
    if (!g) return;
    if (g === 'ok') {
      setNeedLogin(false);
      setNotice('');
      toast('✓ تم الدخول عبر Google', 'success');
      void fetchFiles();
    } else if (g === 'denied') {
      setNotice('أُلغيت عملية الدخول عبر Google.');
    } else if (g === 'invalid' || g === 'unverified') {
      setNotice('تحقّق من حساب Google المسموح به (يجب أن يطابق ADMIN_SYNC_EMAIL) أو من إعدادات OAuth في Google Console.');
    } else {
      setNotice('تعذّر إتمام الدخول عبر Google — حاول لاحقًا.');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams]);

  // paste-list fallback (bypasses the API when it can't be reached)
  const [pasteText, setPasteText] = useState('');
  const [pasteMsg, setPasteMsg] = useState('');

  function applyPaste(): void {
    const res = parsePastedFileList(pasteText);
    if (res.items.length === 0) {
      setPasteMsg('لا توجد روابط Up-4ever صالحة بها أسماء PDF/EPUB في النص.');
      return;
    }
    const known = new Set(items.map((i) => i.file_code));
    const fresh = res.items.filter((i) => !known.has(i.file_code));
    if (fresh.length > 0) {
      setItems((prev) => [...prev, ...fresh]);
      setRows((prev) => {
        const next = { ...prev };
        for (const it of fresh) {
          next[it.file_code] = { checked: true, title: titleFromName(it.name), enrich: { phase: 'idle' } };
        }
        return next;
      });
    }
    const skippedTotal = res.skipped + res.duplicates + (res.items.length - fresh.length);
    setPasteMsg(`تضاف ${fresh.length} للمراجعة · مستبعد/مكرّر ${skippedTotal}`);
    if (fresh.length > 0) toast(`أضيف ${fresh.length} ملفًا إلى قائمة المراجعة`, 'success');
  }

  // existing records → duplicate detection (by file code or share link)
  const existing = useMemo(() => {
    const codes = new Set<string>();
    const links = new Set<string>();
    for (const r of snap.records) {
      for (const f of r.files ?? []) {
        if (f.externalFileId) codes.add(String(f.externalFileId));
        if (f.downloadUrl) links.add(f.downloadUrl.trim());
      }
      if (r.fileUrl) links.add(r.fileUrl.trim());
    }
    return { codes, links };
  }, [snap.records]);

  const isDup = (it: SyncFile) =>
    existing.codes.has(it.file_code) || (!!it.link && existing.links.has(it.link.trim())) || imported.has(it.file_code);

  async function login(): Promise<boolean> {
    setLoggingIn(true);
    setLoginError('');
    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ email: loginEmail.trim(), password: loginPassword }),
      });
      const data = (await res.json().catch(() => null)) as { error?: string } | null;
      if (res.ok) {
        setNeedLogin(false);
        setLoginPassword('');
        return true;
      }
      setLoginError(errMessage(res.status, data));
      return false;
    } catch {
      setLoginError('تعذّر الاتصال بالخادم.');
      return false;
    } finally {
      setLoggingIn(false);
    }
  }

  async function fetchFiles(): Promise<void> {
    setFetching(true);
    setFetchError('');
    try {
      const res = await fetch('/api/up4ever/files', { credentials: 'same-origin' });
      const data = (await res.json().catch(() => null)) as
        | { error?: string; items?: SyncFile[]; stats?: typeof stats }
        | null;
      if (res.status === 401) {
        setNeedLogin(true);
        setFetchError(errMessage(401, data));
        return;
      }
      if (!res.ok) {
        setFetchError(errMessage(res.status, data));
        return;
      }
      const list = Array.isArray(data?.items) ? data.items : [];
      setItems(list);
      setStats(data?.stats ?? null);
      setRows((prev) => {
        const next: Record<string, RowState> = {};
        for (const it of list) {
          next[it.file_code] =
            prev[it.file_code] ??
            { checked: true, title: titleFromName(it.name), enrich: { phase: 'idle' } };
        }
        return next;
      });
      if (list.length === 0) toast('لا توجد ملفات PDF/EPUB في الحساب', 'info');
    } catch {
      setFetchError('تعذّر الاتصال بخادم المزامنة.');
    } finally {
      setFetching(false);
    }
  }

  async function onLoginSubmit(e: FormEvent) {
    e.preventDefault();
    if (await login()) await fetchFiles();
  }

  function setRow(code: string, patch: Partial<RowState>) {
    setRows((r) => (r[code] ? { ...r, [code]: { ...r[code], ...patch } } : r));
  }

  async function enrich(it: SyncFile): Promise<void> {
    const row = rows[it.file_code];
    if (!row) return;
    setRows((r) => ({ ...r, [it.file_code]: { ...r[it.file_code], enrich: { phase: 'loading' } } }));
    try {
      const res = await fetch(`/api/book-search?q=${encodeURIComponent(row.title || titleFromName(it.name))}`, { credentials: 'same-origin' });
      const data = (await res.json().catch(() => null)) as { results?: EnrichData[] } | null;
      if (!res.ok || !data) {
        setRows((r) => ({ ...r, [it.file_code]: { ...r[it.file_code], enrich: { phase: 'failed', message: errMessage(res.status, (data as { error?: string } | null) ?? null) } } }));
        return;
      }
      const results = Array.isArray(data.results) ? data.results : [];
      const match = results.find((m) => reliableMatch(titleFromName(it.name), m.title ?? ''))
        ?? results.find((m) => reliableMatch(row.title, m.title ?? ''));
      if (!match) {
        setRows((r) => ({ ...r, [it.file_code]: { ...r[it.file_code], enrich: { phase: 'nomatch' } } }));
        return;
      }
      const enriched: EnrichData = {
        title: match.title?.trim() || undefined,
        author: match.author?.trim() || undefined,
        year: match.year?.trim() || undefined,
        language: humanLanguage(match.language),
        isbn: match.isbn?.trim() || undefined,
        description: match.description?.trim() || undefined,
        coverUrl: match.coverUrl?.trim() || undefined,
      };
      setRows((r) => ({
        ...r,
        [it.file_code]: {
          ...r[it.file_code],
          // only overwrite the title when it still equals the raw fallback
          title: match.title && r[it.file_code].title === titleFromName(it.name) ? match.title : r[it.file_code].title,
          enrich: { phase: 'done', data: enriched },
        },
      }));
    } catch {
      setRows((r) => ({ ...r, [it.file_code]: { ...r[it.file_code], enrich: { phase: 'failed', message: 'تعذّر الاتصال بخدمة البيانات.' } } }));
    }
  }

  const dupCount = items.filter(isDup).length;
  const selected = items.filter((it) => !isDup(it) && rows[it.file_code]?.checked);

  async function importSelected(): Promise<void> {
    if (selected.length === 0) { toast('لا توجد عناصر محددة للاستيراد', 'info'); return; }
    setImporting(true);
    const used = new Set(snap.records.map((r) => r.slug).filter(Boolean) as string[]);
    const now = new Date().toISOString();
    let n = 0;
    for (const it of selected) {
      const row = rows[it.file_code];
      if (!row) continue;
      const en = row.enrich.phase === 'done' ? row.enrich.data : undefined;
      const title = row.title.trim() || titleFromName(it.name);
      const base = slugify(title);
      let slug = base;
      let i = 2;
      while (used.has(slug)) slug = `${base}-${i++}`;
      used.add(slug);
      const files: BookFile[] = [
        {
          id: `f-up4-${it.file_code}`,
          provider: 'up4ever',
          fileType: it.ext,
          fileName: it.name,
          downloadUrl: it.link, // API-provided share link — never fabricated
          externalFileId: it.file_code,
          isPrimary: true,
          status: 'unverified',
          createdAt: now,
          updatedAt: now,
        },
      ];
      const rec: Omit<BookRecord, 'id'> = {
        title,
        slug,
        contributors: en?.author ? [{ id: `c-${slugify(en.author)}-0`, name: en.author, role: 'author' }] : [],
        categorySlugs: [],
        teaser: '',
        description: en?.description ?? '',
        language: en?.language ?? '',
        yearPublished: en?.year ?? undefined,
        isbn: en?.isbn ?? undefined,
        coverUrl: en?.coverUrl ?? undefined,
        featured: false,
        chapters: [],
        status: 'draft', // unpublished
        visibility: 'private', // private
        source: 'custom',
        files,
        rightsConfirmed: false,
      };
      store.addBook(rec);
      n++;
    }
    setImported((prev) => new Set([...prev, ...selected.map((s) => s.file_code)]));
    setImporting(false);
    toast(`تم استيراد ${n} كتابًا كمسودة وخاص — راجِعها ثم انشرها بنفسك`, 'success');
  }

  const enrichChip = (st: EnrichState) => {
    switch (st.phase) {
      case 'loading': return <span className="chip"><Loader2 size={12} className="spin" /> جارٍ…</span>;
      case 'done': return <span className="chip chip--ok">✓ مُثرّى</span>;
      case 'nomatch': return <span className="chip">لا مطابقة موثوقة — تُترك الحقول فارغة</span>;
      case 'failed': return <span className="chip chip--warn">⚠ تعذّر الإثراء</span>;
      default: return null;
    }
  };

  return (
    <div className="admin-page">
      <div className="admin-page-head">
        <div>
          <Link to={path('books')} className="link-back"><ArrowRight size={16} /> رجوع إلى الكتب</Link>
          <h1>مزامنة Up-4ever</h1>
        </div>
        <div className="row" style={{ gap: 8 }}>
          {!needLogin && (
            <button className="btn btn-outline" onClick={() => setNeedLogin(true)}>
              <Lock size={16} /> دخول المزامنة
            </button>
          )}
          <button className="btn btn-outline" onClick={() => void fetchFiles()} disabled={fetching || needLogin}>
            {fetching ? <Loader2 size={16} className="spin" /> : <RefreshCw size={16} />} {items.length > 0 ? 'تحديث القائمة' : 'جلب ملفات الحساب'}
          </button>
        </div>
      </div>

      <p className="muted" style={{ fontSize: 13, marginTop: -4 }}>
        <FolderTree size={14} /> استيراد ملفات <strong>PDF/EPUB</strong> من حسابك في Up-4ever عبر الواجهة الرسمية
        (بيانات وروابط فقط — <strong>لا يُحمَّل أي ملف</strong>). راجِع العناصر ثم استوردها يدويًا كمسودة وخاص.
      </p>

      <section className="admin-card">
        <h2 className="form-section-title">لصق قائمة ملفات (بديل عند تعذّر جلب الـ API)</h2>
        <p className="muted" style={{ marginTop: -6, marginBottom: 10, fontSize: 13 }}>
          الصق سطور روابطك كما هي (HTML أو نص عادي: رابط + اسم الملف + الحجم) — يُقبل
          <strong> PDF/EPUB فقط</strong>، والرابط يبقى <strong>يدويًا</strong> كما هو (لا يُحمَّل أي ملف).
        </p>
        <textarea
          rows={6}
          dir="ltr"
          value={pasteText}
          onChange={(e) => { setPasteText(e.target.value); setPasteMsg(''); }}
          placeholder={'<a href="https://www.up-4ever.net/xxxx">book.pdf - 7.3 MB</a>'}
          style={{ width: '100%', fontFamily: 'monospace', fontSize: 13 }}
        />
        <div className="row" style={{ gap: 8, marginTop: 8, alignItems: 'center' }}>
          <button type="button" className="btn btn-outline btn-sm" onClick={applyPaste} disabled={!pasteText.trim()}>
            تحضير للمراجعة
          </button>
          {pasteMsg && <small className="muted">{pasteMsg}</small>}
        </div>
      </section>

      {notice && (
        <div className="admin-alert admin-alert--error">
          <AlertTriangle size={16} />
          <span>{notice}</span>
        </div>
      )}

      {needLogin && (
        <section className="admin-card" style={{ maxWidth: 560 }}>
          <h2 className="form-section-title"><Lock size={17} /> دخول المزامنة (حساب الخادم)</h2>
          <div className="row" style={{ justifyContent: 'flex-end', marginTop: -4 }}>
            <button type="button" className="link-btn" onClick={() => setNeedLogin(false)}>إخفاء</button>
          </div>
          <p className="muted" style={{ marginTop: -6, marginBottom: 10, fontSize: 13 }}>
            هذه الحسابات تُضبط <strong>على الخادم فقط</strong> (ADMIN_SYNC_EMAIL / ADMIN_SYNC_PASSWORD) ولا توجد في كود الموقع.
          </p>
          <form onSubmit={(e) => void onLoginSubmit(e)}>
            <label className="field">
              <span className="field-label">البريد</span>
              <input dir="ltr" type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} autoComplete="username" required />
            </label>
            <label className="field">
              <span className="field-label">كلمة المرور</span>
              <input dir="ltr" type="password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} autoComplete="current-password" required />
            </label>
            {loginError && <small className="field-note field-note--err">{loginError}</small>}
            <button className="btn btn-primary" type="submit" disabled={loggingIn} style={{ marginTop: 8 }}>
              {loggingIn ? <Loader2 size={16} className="spin" /> : <Lock size={16} />} دخول
            </button>
          </form>
          {googleOn === true && (
            <>
              <div className="or-sep" style={{ margin: '14px 0 10px' }}><span>أو</span></div>
              <a className="btn btn-outline" href="/api/admin/google/start" style={{ width: '100%', justifyContent: 'center' }}>
                <strong aria-hidden>G</strong> الدخول عبر Google
              </a>
            </>
          )}
          {googleOn === false && (
            <small className="muted" style={{ display: 'block', marginTop: 12 }}>
              الدخول عبر Google غير مفعّل — لتفعيله اضبط على الخادم:
              <code dir="ltr"> GOOGLE_CLIENT_ID</code> + <code dir="ltr">GOOGLE_CLIENT_SECRET</code> +
              <code dir="ltr"> ADMIN_SYNC_EMAIL</code> (بريدك في Gmail). لا حاجة لكلمة سر المزامنة لمسار Google
              (راجع .env.example وGoogle Console — URI: <code dir="ltr">/api/admin/google/callback</code>).
            </small>
          )}
        </section>
      )}

      {fetchError && !needLogin && (
        <div className="admin-alert admin-alert--error">
          <AlertTriangle size={16} />
          <span>{fetchError}</span>
        </div>
      )}

      {items.length > 0 && (
        <section className="admin-card">
          <h2 className="form-section-title">
            مراجعة واختيار ({items.length} ملف PDF/EPUB{dupCount > 0 ? ` · ${dupCount} موجود مسبقًا` : ''})
          </h2>
          {stats && (
            <p className="muted" style={{ marginTop: -6, marginBottom: 10, fontSize: 13 }}>
              صفحات API: {stats.pages ?? '—'} · مجلدات: {stats.folders ?? '—'} ·
              {' '}مستبعدة (غير PDF/EPUB): {stats.excluded ?? '—'} · الإجمالي في الحساب: {stats.filesTotal ?? '—'}
            </p>
          )}

          <div className="meta-result-list">
            {items.map((it) => {
              const row = rows[it.file_code];
              if (!row) return null;
              const dup = isDup(it);
              return (
                <div className="meta-result" key={it.file_code} style={dup ? { opacity: 0.65 } : undefined}>
                  <label title="اختيار" style={{ display: 'flex', alignItems: 'center' }}>
                    <input
                      type="checkbox"
                      checked={row.checked && !dup}
                      disabled={dup}
                      onChange={(e) => setRow(it.file_code, { checked: e.target.checked })}
                    />
                  </label>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
                      <strong>{it.name}</strong>
                      <span className="chip">{it.ext.toUpperCase()}</span>
                      {dup && <span className="chip chip--warn">موجود بالفعل</span>}
                      {it.folder && <small className="muted">{it.folder}</small>}
                    </div>
                    <input
                      dir="auto"
                      value={row.title}
                      onChange={(e) => setRow(it.file_code, { title: e.target.value })}
                      placeholder="عنوان الكتاب (اسم الملف افتراضيًا)"
                      style={{ marginTop: 6, width: '100%', maxWidth: 460 }}
                      disabled={dup}
                    />
                    <small className="muted" style={{ display: 'block' }}>
                      {it.link ? (
                        <a href={it.link || undefined} target="_blank" rel="noopener noreferrer" dir="ltr" style={{ wordBreak: 'break-all' }}>
                          <ExternalLink size={11} /> {it.link}
                        </a>
                      ) : (
                        'بدون رابط مشاركة'
                      )}
                    </small>
                    <div className="row" style={{ gap: 8, marginTop: 6, alignItems: 'center' }}>
                      <button type="button" className="btn btn-outline btn-sm" onClick={() => void enrich(it)} disabled={dup || row.enrich.phase === 'loading'}>
                        {row.enrich.phase === 'loading' ? <Loader2 size={13} className="spin" /> : <Search size={13} />} مطابقة بيانات
                      </button>
                      {enrichChip(row.enrich)}
                      {row.enrich.phase === 'failed' && row.enrich.message && (
                        <small className="field-note field-note--warn">{row.enrich.message}</small>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="row wrap" style={{ gap: 10, marginTop: 14, alignItems: 'center' }}>
            <button className="btn btn-primary" onClick={() => void importSelected()} disabled={importing || selected.length === 0}>
              {importing ? <Loader2 size={16} className="spin" /> : <Upload size={16} />} استيراد {selected.length} كمسودة/خاص
            </button>
            <small className="muted">
              <CheckCircle2 size={13} /> تُستورد كـ <strong>مسودة + خاص</strong> — لا تُنشر تلقائيًا، والحقول غير المعروفة تبقى فارغة للتعديل.
            </small>
          </div>
        </section>
      )}

      {items.length === 0 && !fetching && !fetchError && !needLogin && (
        <section className="admin-card">
          <p className="muted" style={{ margin: 0 }}>
            اضغط «جلب ملفات الحساب» لعرض ملفات PDF/EPUB من Up-4ever (يتطلب جلسة مزامنة ومفتاح API على الخادم).
          </p>
        </section>
      )}
    </div>
  );
}
