# المكتبة الإلكترونية العربية · Bibliothèque électronique arabe

Une bibliothèque numérique arabe **moderne, premium et responsive** — construite avec
**React + TypeScript + Vite**, en RTL, avec des données et des liens **100 % réels**
(livres libres/domaine public : مؤسسة هنداوي).

> Concept : **Bibliothèque → Catégories → Livre → Fiche → Lecture / Téléchargement**
> Identité graphique **originale** (aucune copie de ktobati.com).

## ✨ Fonctionnalités

- Accueil premium (Hero + grande recherche, catégories, sections de livres, CTA)
- Cartes livres élégantes (hover, zoom, ombres, coins arrondis)
- Fiche livre : نبذة، معلومات، **الفهرس القابل للنقر**، عن المؤلف، كتب ذات صلة
- Recherche globale **instantanée** (avec normalisation arabe) + suggestions
- Filtres dynamiques (التصنيف / المؤلف / اللغة) + tri + bascule grille/liste
- Mega-menu desktop + menu hamburger mobile · Breadcrumb partout
- Lecture en ligne + téléchargement **PDF / ePub / Kindle** (liens réels)
- SEO complet : meta, Open Graph, JSON-LD, `robots.txt`, `sitemap.xml`
- Performance : routes lazy, images lazy, aucun PDF chargé au démarrage
- Accessibilité & responsive (desktop / tablette / mobile)

## 🚀 Démarrage

```bash
npm install
npm run dev            # http://localhost:5173
npm run build          # build de production
node scripts/gen-sitemap.mjs   # (re)génère public/sitemap.xml
```

## 🛠️ Tableau de bord / CMS (`/admin`)

Un **back-office complet** permet de gérer tout le catalogue sans toucher au code —
les changements apparaissent automatiquement sur le site public.

- **Accès** : `/admin` (ou `/dashboard`). Connexion e-mail + mot de passe.
- **Identifiants de démo** : `admin@maktaba.local` / `admin1234`
  (configurables via `VITE_ADMIN_EMAIL` / `VITE_ADMIN_PASSWORD`, voir `.env.example`).
- **Fonctions** : tableau de bord (stats réelles), liste des livres (recherche, filtres,
  voir/modifier/dupliquer/supprimer/publier), formulaire d'ajout/édition (upload
  couverture JPG/PNG/WEBP + aperçu, fichier PDF/EPUB **ou** URL externe, glisser-déposer,
  brouillon/publié/archivé, public/privé, slug auto `/livre/:slug`, validation avant
  publication), catégories CRUD dynamiques, auteurs (bio/photo/pays/site), import CSV
  (assistant 7 étapes avec validation ✓/⚠️ et barre de progression), import multiple de
  couvertures (correspondance par nom de fichier), ressources, liens, paramètres.

> ⚠️ **Sécurité** : la connexion actuelle est **uniquement front-end** (démo) et ne
> constitue **pas** une vraie protection. Pour la production, branchez **Supabase Auth**
> avec les politiques RLS fournies dans **[`supabase/schema.sql`](./supabase/schema.sql)**
> (lecture publique limitée aux livres publiés ; écriture réservée aux admins). Ne mettez
> jamais de clé `service_role` ou de secret dans le bundle frontend.

**Persistance locale** : le catalogue est stocké dans le navigateur (`localStorage` pour
les métadonnées, `IndexedDB` pour les fichiers/couvertures téléversés), derrière une
couche de données prête pour Supabase.

### 📁 Stockage externe des fichiers (PDF/EPUB)

Les fichiers volumineux **ne sont jamais stockés dans le bundle** ni dans `public/`.
Chaque livre peut avoir **plusieurs fichiers** (PDF **et** EPUB) hébergés indépendamment :

- Fournisseurs supportés : **OneDrive, Up-4ever, FileInk, RapidFiles, FileFire,
  Supabase Storage, URL externe** + téléversement local (IndexedDB). L'abstraction
  `StorageProvider` (`src/store/links.ts`) permet d'ajouter Google Drive, Dropbox, S3,
  R2… sans toucher au reste de l'app.
- Dans le formulaire livre : section **« 📁 Fichiers du livre »** → format (PDF/EPUB),
  hébergeur, `download_url`, `read_url` (optionnel), **bouton Tester le lien**, fichier
  principal, suppression. Les URLs ne sont **jamais** inventées.
- **Test de lien** : valide le format + HTTPS ; ne bloque jamais abusivement un hôte qui
  refuse la vérification (CORS) → affiche « ⚠️ Impossible de vérifier ».
- **Droits d'auteur** : case de confirmation obligatoire avant de publier des fichiers.
- **Migration** : les anciens champs (`fileUrl`, `fileAssetId`…) sont migrés
  automatiquement vers le nouveau modèle `book_files`, sans perte de données.
- Côté public (`/livre/:slug`) : un bouton **📥 Télécharger** par format, plus
  **📖 Lire** si une URL de lecture existe. Le bouton redirige simplement vers l'URL
  réelle du fournisseur (aucune monétisation simulée).
- **Sécurité** : seules des **URLs publiques** sont stockées en base. Toute clé d'API
  (OneDrive Graph, PPD…) reste **côté serveur** (voir `.env.example`).

> **Déploiement Netlify** : `netlify.toml` + `public/_redirects` assurent le fallback SPA
> (`/* → /index.html`) pour que `/admin`, `/dashboard` et `/livre/:slug` fonctionnent au
> rafraîchissement.

### 🔎 Recherche de métadonnées (Internet Archive)

Le formulaire **Ajouter un livre** (`/admin/books/new`) inclut une recherche de
**métadonnées uniquement** (titre, auteur, année, langue, ISBN, description, URL de
couverture) adossée à l'API publique **Internet Archive** (`advancedsearch`) — la source
initiale par défaut du projet :

- **Endpoint homonyme (même origine)** : `GET /api/book-search?q=…` →
  JSON `{ "source": "internet_archive", "results": [{ identifier, title, author, year, language, isbn, description, coverUrl }] }`.
- **Côté serveur uniquement** : fonction Netlify (`netlify/functions/book-search.mjs`)
  en production, middleware Vite équivalent (`vite.config.ts` → `server/book-search.mjs`)
  pour `npm run dev` / `npm run preview`. Le navigateur n'appelle jamais directement
  archive.org ; aucun secret n'est exposé au bundle, et aucun livre n'est téléchargé :
  seuls des **champs de métadonnées** + l'URL de la vignette de couverture sont renvoyés.
  **Aucun PDF/EPUB n'est jamais téléchargé ni stocké** par cette recherche.
- **Après « استخدام البيانات »** : le formulaire est rempli (couverture via le champ
  `coverUrl` existant, slug automatique conservé) ; les fichiers manuels **Up-4ever /
  OneDrive déjà saisis restent intacts**, et le livre reste **brouillon + privé** jusqu'à
  publication manuelle (bouton « نشر »).
- La recherche est uniquement disponible sur la création (pas sur l'édition) pour ne pas
  modifier les autres workflows de gestion des livres.

### 🔄 Synchronisation Up-4ever (compte admin, `/admin/up4ever`)

Import des fichiers **PDF/EPUB déjà hébergés dans VOTRE compte Up-4ever** via l'API
officielle (`https://www.up-4ever.net/pages/api`) — Up-4ever n'offre aucune recherche
globale publique : l'API ne liste que les fichiers du compte authentifié.

- **Endpoints homonymes (même origine)**
  - `POST /api/admin/login` — vérifie `ADMIN_SYNC_EMAIL` / `ADMIN_SYNC_PASSWORD`
    (**variables de serveur**, jamais `VITE_*`, jamais dans le bundle) puis pose un
    cookie de session **HttpOnly + Secure + SameSite=Strict, limité à `/api`** (8 h).
  - `GET /api/admin/google/status` · `GET /api/admin/google/start` ·
    `GET /api/admin/google/callback` — **« الدخول عبر Google »** (flux authorization
    code, serveur uniquement) : `GOOGLE_CLIENT_ID`/`GOOGLE_CLIENT_SECRET` restent côté
    serveur, l'`id_token` est **vérifié localement (RS256 + JWKS Google : aud/iss/exp,
    email vérifié = `ADMIN_SYNC_EMAIL`)** puis la **même session cookie** est posée.
    Échec bloqué : tant que `GOOGLE_*` + `ADMIN_SYNC_EMAIL` ne sont pas configurés →
    `503 google_not_configured` et le bouton reste masqué (URI de redirection à
    autoriser dans Google Console : `/api/admin/google/callback`, voir `.env.example`).
    **Setup « Google seulement »** : `ADMIN_SYNC_PASSWORD` n'est PAS requis — la
    session est signée par `GOOGLE_CLIENT_SECRET` (côté serveur) ; le formulaire
    e-mail/mot de passe reste désactivé tant que ce mot de passe n'est pas défini.
  - `GET /api/up4ever/files` — **échec bloqué** (401 sans session valide) : liste les
    fichiers du compte via `GET /file/list` (péage `per_page=200&page=N`, scope
    `files_read`) + parcours récursif `GET /folder/list?fld_id=…` depuis le dossier 0
    (scope `folders`), cadencé (~350 ms/appel, 1 retry sur 429/5xx), dédupliqué par
    `file_code`, borné (50 pages / 400 dossiers), et filtré aux **PDF/EPUB uniquement**.
- **Sécrets** : `UP4EVER_API_KEY` (voir `.env.example`) est lu uniquement côté serveur
  et transmis à Up-4ever en `Authorization: Bearer …` (jamais dans une URL, un log ou
  le navigateur). **Aucun octet de fichier n'est téléchargé** : seule la *metadata* +
  le lien de partage (`link`) sont conservés.
- **Flux** : connexion (session) → « جلب ملفات الحساب » → **étape de revue** (titre
  éditable — nom du fichier en secours, case à cocher, exclusion des doublons détectés
  par `file_code`/lien) → « مطابقة بيانات » (enrichissement via la recherche de
  métadonnées existante, **uniquement si la correspondance est fiable**, sinon champs
  laissés vides) → **import déclenché à la main**.
- **Liste collée (fallback hors API)** : le même écran accepte le **collage direct**
  de la liste de fichiers (`<a href="…">nom - taille</a>` ou `URL - nom.pdf - 7,3 MB`)
  via « تحضير للمراجعة » — parser PDF/EPUB uniquement (`src/utils/pasteList.ts`),
  `file_code` = slug de l'URL (équivalent à l'API → anti-doublon commun), mêmes
  règles de revue/import. Utile lorsque le sandbox/serveur ne peut pas joindre
  up-4ever.net.
- **Import** : chaque élément devient un enregistrement **`draft` + `private`** avec
  `provider: 'up4ever'`, `download_url` = lien fourni par l'API, `externalFileId` =
  `file_code` (anti-doublon aux re-synchronisations). Aucune publication automatique,
  `rightsConfirmed` reste à confirmer côté fiche. Le workflow manuel Up-4ever existant
  (ajout de lien dans le formulaire livre) est inchangé.
- **Local** : `.env.local` (ignoré par git) pour `ADMIN_SYNC_*` + `UP4EVER_API_KEY`.
  **Production** : mêmes variables côté serveur (ex. paramètres d'environnement Netlify).
  ⚠️ La clé Up-4ever doit être **demandée/approuvée dans votre compte Up-4ever** puis
  configurée côté serveur — jamais collée dans une conversation ni dans le code client.
- Les états d'erreur sont explicites côté UI : `auth_not_configured`, `unauthorized`,
  `missing_api_key`, `up4ever_rejected` (scopes/approbation), `up4ever_rate_limited`,
  `up4ever_unavailable`.

## 🖥️ Déploiement — Hostinger (Node.js)

L'application tourne en **application Node.js** standard : le serveur de production
`server/index.mjs` (aucune dépendance supplémentaire, Node 24) sert le build Vite
(`dist/`) avec fallback SPA **et** route les endpoints serveur existants via les
mêmes modules (`server/*.mjs`) :

| Route | Module |
| --- | --- |
| `GET /api/book-search` | `server/book-search.mjs` (métadonnées uniquement) |
| `POST /api/admin/login` | `server/sync-api.mjs` (session HttpOnly) |
| `GET /api/up4ever/files` | `server/sync-api.mjs` (échec bloqué sans session) |
| `GET /api/admin/google/{status,start,callback}` | `server/google-auth.mjs` |

### Étapes Hostinger
1. **Exporter le projet** : téléverser l'arborescence source (sans `node_modules/`,
   sans fichiers d'env locaux) via Git ou le gestionnaire de fichiers hPanel.
2. **hPanel → Site web → Node.js** (application) : choisir **Node 24** puis
   - commande d'installation : `npm install`
   - commande de build : `npm run build`
   - commande de démarrage (Start command) : **`npm start`**
     (= `node server/index.mjs`, écoute sur `process.env.PORT`, fallback `3000`,
     interface `0.0.0.0`)
3. **Variables d'environnement** — ajouter **exactement ces noms** dans le tableau
   de bord Hostinger (espace variables d'environnement de l'app ; les **valeurs**
   ne vont **jamais** dans le dépôt, le build ni `dist/`) :

   | Nom (exact) | Rôle |
   | --- | --- |
   | `UP4EVER_API_KEY` | clé API Up-4ever (Bearer, côté serveur uniquement) |
   | `ADMIN_SYNC_EMAIL` | identifiant e-mail de la session de synchronisation |
   | `ADMIN_SYNC_PASSWORD` | mot de passe de cette session (signe les cookies) |
   | `GOOGLE_CLIENT_ID` | OAuth client ID (optionnel — « الدخول عبر Google ») |
   | `GOOGLE_CLIENT_SECRET` | OAuth client secret (optionnel, côté serveur) |

   (`PORT` est injecté par Hostinger ; le serveur l'utilise automatiquement.)
   Le serveur lit **uniquement `process.env`** à l'exécution — aucun fichier local
   n'est lu ni inclus dans l'export.
4. **Google (optionnel)** : ajouter l'URI de redirection exacte dans Google Console —
   `https://VOTRE-DOMAINE/api/admin/google/callback`.
5. **Santé** : `https://VOTRE-DOMAINE/` sert l'app ; une URL de route type
   `/admin/up4ever` répond aussi 200 (fallback SPA) ; sans variables configurées,
   les endpoints répondent en échec bloqué (`503/401`) — l'app publique reste
   entièrement fonctionnelle.

> Vérification locale du même chemin de production :
> `npm run build && PORT=3000 npm start`.

## 🗂️ Structure

```
src/
├── components/   composants réutilisables (BookCard, SearchBar, FilterBar, Header…)
├── pages/        Home, Books, Categories, Category, BookDetails, Authors, Author, Search, 404
├── admin/        CMS : AdminApp, AdminLayout, auth, toasts, pages (Dashboard, BookForm, …)
├── store/        store réactif (useSyncExternalStore) + IndexedDB + dérivations/recherche
├── data/         types + catégories + livres réels (books.raw.ts)
├── hooks/        useReveal, useSeo
├── utils/        format (chiffres arabes), search (normalisation arabe)
└── styles/       design system (global.css) + composants (components.css) + admin (admin.css)
supabase/
└── schema.sql    schéma Postgres + RLS + buckets storage (backend prêt à l'emploi)
```

## ➕ Ajouter un livre

Ajoutez un objet dans `src/data/books.raw.ts` (id réel + métadonnées). Les couvertures,
liens de téléchargement/lecture, catégories, auteurs, recherche et sitemap se mettent à
jour automatiquement.

Voir **[REPORT.md](./REPORT.md)** pour le rapport complet (analyse, tests, décisions).
