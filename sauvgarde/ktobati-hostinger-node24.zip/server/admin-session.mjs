/**
 * Minimal SERVER-ONLY admin session for the sync routes.
 * Credentials come exclusively from server environment (never VITE_*):
 *   ADMIN_SYNC_EMAIL / ADMIN_SYNC_PASSWORD   (see .env.example)
 * Session = HMAC-signed token stored in an HttpOnly cookie (stateless).
 */
import { createHmac, randomBytes, timingSafeEqual, createHash } from 'node:crypto';

const COOKIE_NAME = 'ktobati_sync';
const MAX_AGE = 8 * 60 * 60; // 8h

function envCreds(env) {
  const email = env?.ADMIN_SYNC_EMAIL;
  const password = env?.ADMIN_SYNC_PASSWORD;
  if (typeof email === 'string' && typeof password === 'string' && email.trim() && password.length > 0) {
    return { email: email.trim(), password };
  }
  return null;
}

/**
 * Secret used to sign/verify session tokens.
 * Prefers the sync password; falls back to the Google client secret so
 * Google-only setups (no ADMIN_SYNC_PASSWORD) can hold a valid session.
 * Server-only either way — never reaches the browser.
 */
export function sessionSecret(env) {
  const pw = env?.ADMIN_SYNC_PASSWORD;
  if (typeof pw === 'string' && pw.length > 0) return pw;
  const gs = env?.GOOGLE_CLIENT_SECRET;
  if (typeof gs === 'string' && gs.trim().length > 0) return gs.trim();
  return null;
}

/** Constant-time string compare (hash first → equal lengths). */
function safeEqual(a, b) {
  const ha = createHash('sha256').update(String(a)).digest();
  const hb = createHash('sha256').update(String(b)).digest();
  return timingSafeEqual(ha, hb);
}

function sign(data, password) {
  return createHmac('sha256', password).update(data).digest('base64url');
}

/** Issue a signed session token, or null when no server secret is configured. */
export function issueToken(env) {
  const secret = sessionSecret(env);
  if (!secret) return null;
  const exp = String(Math.floor(Date.now() / 1000) + MAX_AGE);
  const nonce = randomBytes(9).toString('base64url');
  const data = `v1.${exp}.${nonce}`;
  return `${data}.${sign(data, secret)}`;
}

/** Verify a session token (fail closed on missing config / bad format / expiry). */
export function verifyToken(token, env) {
  const secret = sessionSecret(env);
  if (!secret || typeof token !== 'string') return false;
  const parts = token.split('.');
  // issueToken emits exactly: v1.<exp>.<nonce>.<mac>  → 4 dot-separated parts
  if (parts.length !== 4 || parts[0] !== 'v1') return false;
  const data = `${parts[0]}.${parts[1]}.${parts[2]}`;
  const mac = parts[3]; // base64url never contains '.'
  const expected = sign(data, secret);
  let macOk = false;
  try {
    macOk = timingSafeEqual(Buffer.from(mac, 'base64url'), Buffer.from(expected, 'base64url'));
  } catch {
    macOk = false;
  }
  if (!macOk) return false;
  const exp = Number(parts[1]);
  return Number.isFinite(exp) && exp * 1000 > Date.now();
}

/** Verify submitted credentials against server env (timing-safe). */
export function checkCredentials(submitted, env) {
  const creds = envCreds(env);
  if (!creds || !submitted || typeof submitted.email !== 'string' || typeof submitted.password !== 'string') {
    return false;
  }
  return safeEqual(submitted.email.trim().toLowerCase(), creds.email.toLowerCase()) && safeEqual(submitted.password, creds.password);
}

export function authConfigured(env) {
  return envCreds(env) !== null;
}

/** Parse a Cookie request header. */
export function parseCookies(header) {
  const out = {};
  if (typeof header !== 'string' || !header) return out;
  for (const part of header.split(';')) {
    const i = part.indexOf('=');
    if (i <= 0) continue;
    const k = part.slice(0, i).trim();
    const v = part.slice(i + 1).trim();
    if (k) out[k] = v;
  }
  return out;
}

/**
 * Set-Cookie for the session: HttpOnly + Secure + SameSite=Strict, scoped to /api.
 * The token is never readable from JS (no client storage of secrets).
 */
export function sessionSetCookie(token) {
  return `${COOKIE_NAME}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/api; Max-Age=${MAX_AGE}`;
}

export function sessionClearCookie() {
  return `${COOKIE_NAME}=; HttpOnly; Secure; SameSite=Strict; Path=/api; Max-Age=0`;
}

export function tokenFromRequest(cookieHeader) {
  return parseCookies(cookieHeader)[COOKIE_NAME] ?? '';
}
