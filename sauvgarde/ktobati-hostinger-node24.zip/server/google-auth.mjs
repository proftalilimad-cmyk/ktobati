/**
 * "Sign in with Google" for the sync login (authorization-code flow).
 *
 * SERVER-ONLY secrets: GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET (never in the
 * bundle, URLs sent to the browser, or logs — the secret goes only to Google's
 * token endpoint from the server).
 *
 * Fail closed everywhere: until GOOGLE_* + ADMIN_SYNC_* are configured, every
 * route answers 503 google_not_configured and no session can be issued.
 * Success = server-verified Google identity (RS256 id_token via Google JWKS,
 * aud/iss/exp/email checks, verified email must equal ADMIN_SYNC_EMAIL) →
 * the same HttpOnly/Secure/SameSite session cookie as the password login.
 *
 * NOTE: this sandbox cannot reach accounts.google.com — only construction,
 * state verification and fail-closed branches are exercisable here.
 */
import { createHmac, randomBytes, createPublicKey, verify as rsaVerify } from 'node:crypto';
import { issueToken, sessionSetCookie, sessionSecret } from './admin-session.mjs';

const AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
const JWKS_ENDPOINT = 'https://www.googleapis.com/oauth2/v2/certs';
const SCOPES = 'openid email profile';
const STATE_TTL_S = 600;
const TIMEOUT_MS = 10000;
const APP_RETURN = '/admin/up4ever';

const GOOGLE_ISSUERS = ['https://accounts.google.com', 'accounts.google.com'];

function jsonResult(status, body) {
  return {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' },
    body: JSON.stringify(body),
  };
}

function redirect(location, extraHeaders) {
  return { status: 302, headers: { Location: location, 'Cache-Control': 'no-store', ...(extraHeaders ?? {}) }, body: '' };
}

function configured(env) {
  // Google-only setup: no ADMIN_SYNC_PASSWORD required — the client secret
  // (server-only) signs the session. ADMIN_SYNC_EMAIL is the allowlist.
  const need = ['GOOGLE_CLIENT_ID', 'GOOGLE_CLIENT_SECRET', 'ADMIN_SYNC_EMAIL'];
  return need.every((k) => typeof env?.[k] === 'string' && env[k].trim().length > 0);
}

/** Build the app origin from request headers (proxy-aware, localhost→http). */
export function originFromHeaders(headers) {
  const rawProto = headers?.['x-forwarded-proto'];
  const proto = String(Array.isArray(rawProto) ? rawProto[0] : rawProto ?? '').split(',')[0].trim();
  const rawHost = headers?.host;
  const host = String(Array.isArray(rawHost) ? rawHost[0] : rawHost ?? 'localhost:5173').trim() || 'localhost:5173';
  const isLocal = /^localhost(:\d+)?$/.test(host) || /^127\./.test(host) || /^\[?::1\]?/.test(host);
  const scheme = proto === 'https' || proto === 'http' ? proto : isLocal ? 'http' : 'https';
  return `${scheme}://${host}`;
}

/** GET /api/admin/google/status → {configured} (boolean only — no secrets). */
export function googleStatus(env) {
  return jsonResult(200, { configured: configured(env) });
}

/* ---- CSRF state: g1.<exp>.<nonce>.<mac> signed with the session secret ---- */
function stateMac(data, secret) {
  return createHmac('sha256', secret).update(data).digest('base64url');
}
function issueState(secret) {
  const data = `g1.${Math.floor(Date.now() / 1000) + STATE_TTL_S}.${randomBytes(9).toString('base64url')}`;
  return `${data}.${stateMac(data, secret)}`;
}
function verifyState(state, secret) {
  if (typeof state !== 'string') return false;
  const parts = state.split('.');
  if (parts.length !== 4 || parts[0] !== 'g1') return false;
  const data = `${parts[0]}.${parts[1]}.${parts[2]}`;
  const expected = stateMac(data, secret);
  if (parts[3].length !== expected.length) return false;
  let ok = true;
  for (let i = 0; i < parts[3].length; i++) if (parts[3][i] !== expected[i]) ok = false;
  if (!ok) return false;
  const exp = Number(parts[1]);
  return Number.isFinite(exp) && exp * 1000 > Date.now();
}

/** GET /api/admin/google/start → 302 to Google's consent screen. */
export function googleStart({ origin, env }) {
  if (!configured(env)) return jsonResult(503, { error: 'google_not_configured' });
  const redirectUri = `${origin}/api/admin/google/callback`;
  const params = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID.trim(),
    redirect_uri: redirectUri,
    response_type: 'code',
    scope: SCOPES,
    state: issueState(sessionSecret(env) ?? ''),
    prompt: 'select_account',
  });
  return redirect(`${AUTH_ENDPOINT}?${params.toString()}`);
}

function b64json(part) {
  return JSON.parse(Buffer.from(part, 'base64url').toString('utf8'));
}

async function fetchJson(url, options, fetchImpl) {
  let res;
  try {
    res = await fetchImpl(url, {
      ...options,
      signal: typeof AbortSignal !== 'undefined' && AbortSignal.timeout ? AbortSignal.timeout(TIMEOUT_MS) : undefined,
    });
  } catch {
    const e = new Error('unreachable');
    e.kind = 'network';
    throw e;
  }
  if (!res.ok) {
    const e = new Error(`status ${res.status}`);
    e.kind = 'upstream';
    throw e;
  }
  try {
    return await res.json();
  } catch {
    const e = new Error('invalid json');
    e.kind = 'upstream';
    throw e;
  }
}

/** Verify a Google id_token locally against Google's JWKS (RS256). */
async function verifyIdToken(idToken, env, fetchImpl) {
  const segs = String(idToken).split('.');
  if (segs.length !== 3) throw Object.assign(new Error('malformed'), { kind: 'verify' });
  let header, payload;
  try {
    header = b64json(segs[0]);
    payload = b64json(segs[1]);
  } catch {
    throw Object.assign(new Error('malformed'), { kind: 'verify' });
  }
  if (header.alg !== 'RS256') throw Object.assign(new Error('alg'), { kind: 'verify' });

  const jwks = await fetchJson(JWKS_ENDPOINT, { headers: { Accept: 'application/json' } }, fetchImpl);
  const keys = Array.isArray(jwks) ? jwks : Array.isArray(jwks?.keys) ? jwks.keys : [];
  const candidates = header.kid ? keys.filter((k) => k.kid === header.kid) : keys;
  if (candidates.length === 0) throw Object.assign(new Error('kid'), { kind: 'verify' });

  const signed = Buffer.from(`${segs[0]}.${segs[1]}`);
  const sig = Buffer.from(segs[2], 'base64url');
  let signatureOk = false;
  for (const jwk of candidates) {
    try {
      const pub = createPublicKey({ key: jwk, format: 'jwk' });
      if (rsaVerify('RSA-SHA256', signed, pub, sig)) { signatureOk = true; break; }
    } catch {
      /* try next key */
    }
  }
  if (!signatureOk) throw Object.assign(new Error('signature'), { kind: 'verify' });

  const now = Math.floor(Date.now() / 1000);
  const aud = payload.aud;
  const audOk = aud === env.GOOGLE_CLIENT_ID.trim() || (Array.isArray(aud) && aud.includes(env.GOOGLE_CLIENT_ID.trim()));
  const issOk = GOOGLE_ISSUERS.includes(payload.iss);
  const expOk = Number.isFinite(payload.exp) && payload.exp > now;
  const emailOk =
    typeof payload.email === 'string' &&
    (payload.email_verified === true || payload.email_verified === 'true') &&
    payload.email.trim().toLowerCase() === String(env.ADMIN_SYNC_EMAIL).trim().toLowerCase();
  if (!audOk || !issOk || !expOk || !emailOk) throw Object.assign(new Error('claims'), { kind: 'verify' });
  return payload.email;
}

/** GET /api/admin/google/callback — complete the flow, set the session cookie. */
export async function googleCallback({ query, origin, env, fetchImpl = fetch }) {
  if (!configured(env)) return jsonResult(503, { error: 'google_not_configured' });

  // explicit denial from Google — no session
  if (query?.error) return redirect(`${APP_RETURN}?google=denied`);

  const code = query?.code;
  const state = query?.state;
  if (!code || !verifyState(state, sessionSecret(env) ?? '')) {
    return redirect(`${APP_RETURN}?google=invalid`);
  }

  // 1) exchange the code (client_secret stays server-side, sent only to Google)
  let tokens;
  try {
    const body = new URLSearchParams({
      code: String(code),
      client_id: env.GOOGLE_CLIENT_ID.trim(),
      client_secret: env.GOOGLE_CLIENT_SECRET.trim(),
      redirect_uri: `${origin}/api/admin/google/callback`,
      grant_type: 'authorization_code',
    });
    tokens = await fetchJson(
      TOKEN_ENDPOINT,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
        body: body.toString(),
      },
      fetchImpl,
    );
  } catch (e) {
    return redirect(`${APP_RETURN}?google=${e.kind === 'network' ? 'unreachable' : 'token_error'}`);
  }
  if (!tokens || typeof tokens.id_token !== 'string') {
    return redirect(`${APP_RETURN}?google=token_error`);
  }

  // 2) verify the id_token (signature + claims) — fail closed on anything odd
  try {
    await verifyIdToken(tokens.id_token, env, fetchImpl);
  } catch (e) {
    return redirect(`${APP_RETURN}?google=${e.kind === 'network' ? 'unreachable' : 'unverified'}`);
  }

  // 3) issue the normal session (signed with the server-side session secret)
  const token = issueToken(env);
  if (!token) return jsonResult(503, { error: 'google_not_configured' });
  return redirect(`${APP_RETURN}?google=ok`, { 'Set-Cookie': sessionSetCookie(token) });
}
