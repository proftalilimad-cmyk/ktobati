/** Server-side sync API (shared by Vite middleware and Netlify Functions). */
export interface SyncEnv {
  ADMIN_SYNC_EMAIL?: string;
  ADMIN_SYNC_PASSWORD?: string;
  UP4EVER_API_KEY?: string;
  GOOGLE_CLIENT_ID?: string;
  GOOGLE_CLIENT_SECRET?: string;
}

export interface SyncHandlerResult {
  status: number;
  body: unknown;
  headers: Record<string, string>;
}

/** POST /api/admin/login — rawBody is the raw JSON request body. */
export declare function adminLogin(args: { rawBody: string; env: SyncEnv }): Promise<SyncHandlerResult>;

/** GET /api/up4ever/files — cookieHeader is the raw Cookie request header. */
export declare function up4everFiles(args: { cookieHeader: string; env: SyncEnv }): Promise<SyncHandlerResult>;
