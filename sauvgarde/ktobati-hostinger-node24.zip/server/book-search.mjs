/**
 * Shared server-side handler: metadata search against the Internet Archive's
 * public advancedsearch API.
 *
 * METADATA ONLY — this module NEVER downloads or stores book files
 * (PDF/EPUB/…). It returns bibliographic fields plus a cover-thumbnail URL.
 *
 * Used by:
 *  - the Vite dev/preview middleware (vite.config.ts)  → GET /api/book-search
 *  - the Netlify Function (netlify/functions/book-search.mjs) → same path
 */

const IA_ENDPOINT = 'https://archive.org/advancedsearch.php';
/** Metadata fields only — no file/mediatype download fields are requested. */
const FIELDS = ['identifier', 'title', 'creator', 'year', 'date', 'language', 'isbn', 'description'];
const ROWS = 10;
const TIMEOUT_MS = 8000;
const MAX_QUERY = 200;
const MAX_DESCRIPTION = 1600;

/** Upstream (archive.org) failed to answer — mapped to HTTP 502. */
export class UpstreamError extends Error {
  constructor(message) {
    super(message);
    this.name = 'UpstreamError';
  }
}

function first(value) {
  if (Array.isArray(value)) return value.length ? first(value[0]) : undefined;
  if (value === null || value === undefined) return undefined;
  const s = String(value).trim();
  return s || undefined;
}

function stripHtml(text) {
  if (!text) return undefined;
  const s = String(text)
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#0?39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
  return s ? s.slice(0, MAX_DESCRIPTION) : undefined;
}

function yearOf(doc) {
  const y = first(doc.year);
  if (y) {
    const m = String(y).match(/\d{4}/);
    if (m) return m[0];
  }
  const d = first(doc.date);
  if (d) {
    const m = String(d).match(/^\s*(\d{4})/);
    if (m) return m[1];
  }
  return undefined;
}

function mapDoc(doc) {
  if (!doc || typeof doc.identifier !== 'string' || !doc.identifier) return null;
  const identifier = doc.identifier;
  const result = {
    identifier,
    title: first(doc.title) ?? identifier,
    coverUrl: `https://archive.org/services/img/${identifier}`,
  };
  const author = first(doc.creator);
  if (author) result.author = author;
  const year = yearOf(doc);
  if (year) result.year = year;
  const language = first(doc.language);
  if (language) result.language = language;
  const isbn = first(doc.isbn);
  if (isbn) result.isbn = isbn;
  const description = stripHtml(first(doc.description));
  if (description) result.description = description;
  return result;
}

/**
 * Search Internet Archive metadata (no API key, public endpoint).
 * @param {unknown} query free-text query (title / author / ISBN…)
 * @returns {Promise<{source: 'internet_archive', results: object[]}>}
 * @throws {Error} `EMPTY_QUERY` for a blank query
 * @throws {UpstreamError} when archive.org is unreachable or answers badly
 */
export async function searchBooks(query) {
  const q = String(query ?? '').trim().slice(0, MAX_QUERY);
  if (!q) {
    throw new Error('EMPTY_QUERY');
  }
  // neutralise quotes/backslashes so user input cannot break the query syntax
  const safe = q.replace(/["\\]/g, ' ').replace(/\s+/g, ' ').trim();

  const params = new URLSearchParams();
  params.set('q', `${safe} AND mediatype:(texts)`);
  for (const f of FIELDS) params.append('fl[]', f);
  params.set('rows', String(ROWS));
  params.set('page', '1');
  params.set('output', 'json');

  let res;
  try {
    res = await fetch(`${IA_ENDPOINT}?${params.toString()}`, {
      headers: {
        'User-Agent': 'ktobati-admin/1.0 (+metadata search)',
        Accept: 'application/json',
      },
      signal: typeof AbortSignal !== 'undefined' && AbortSignal.timeout ? AbortSignal.timeout(TIMEOUT_MS) : undefined,
    });
  } catch {
    throw new UpstreamError('internet archive unreachable');
  }
  if (!res.ok) throw new UpstreamError(`internet archive responded ${res.status}`);

  let data;
  try {
    data = await res.json();
  } catch {
    throw new UpstreamError('invalid response from internet archive');
  }
  const docs = Array.isArray(data?.response?.docs) ? data.response.docs : [];
  return {
    source: 'internet_archive',
    results: docs.map(mapDoc).filter(Boolean),
  };
}
