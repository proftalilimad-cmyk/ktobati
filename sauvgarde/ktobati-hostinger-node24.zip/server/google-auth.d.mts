/** Google sign-in for the sync routes (server-only, fail closed). */
export interface GoogleResult {
  status: number;
  headers: Record<string, string>;
  body: string;
}

/** Build the app origin from request headers (proxy-aware, localhost→http). */
export declare function originFromHeaders(headers: Record<string, unknown>): string;

/** GET /api/admin/google/status → 200 {"configured": boolean} */
export declare function googleStatus(env: unknown): GoogleResult;

/** GET /api/admin/google/start → 302 to Google, or 503 google_not_configured. */
export declare function googleStart(args: { origin: string; env: unknown }): GoogleResult;

/** GET /api/admin/google/callback → 302 back to the app (+ session cookie) or 503. */
export declare function googleCallback(args: {
  query: Record<string, string>;
  origin: string;
  env: unknown;
  fetchImpl?: typeof fetch;
}): Promise<GoogleResult>;
