#!/usr/bin/env node
/**
 * Production Node.js server — Hostinger web-app entry (`npm start`).
 *
 * Serves the built Vite app from dist/ (SPA fallback for client routes) and
 * routes the existing same-origin server endpoints through the existing
 * server modules:
 *
 *   GET  /api/book-search                → server/book-search.mjs   (metadata only)
 *   POST /api/admin/login                → server/sync-api.mjs      (server-only creds)
 *   GET  /api/up4ever/files              → server/sync-api.mjs      (cookie-gated)
 *   GET  /api/admin/google/status        → server/google-auth.mjs
 *   GET  /api/admin/google/start         → server/google-auth.mjs
 *   GET  /api/admin/google/callback      → server/google-auth.mjs
 *
 * Secrets are read ONLY from process.env at runtime — set them in the
 * Hostinger dashboard (see README). They are never sent to the client,
 * logged, or placed in URLs. This file never reads any env file.
 *
 * Node 24 (global fetch). No new dependencies.
 */
import { createServer } from 'node:http';
import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { searchBooks, UpstreamError as BookUpstreamError } from './book-search.mjs';
import { adminLogin, up4everFiles } from './sync-api.mjs';
import { googleStatus, googleStart, googleCallback, originFromHeaders } from './google-auth.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const DIST = path.join(HERE, '..', 'dist');
const PORT = Number(process.env.PORT) || 3000;
const HOST = '0.0.0.0';
const MAX_BODY = 65536;

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.pdf': 'application/pdf',
};

function sendJson(res, status, body, extraHeaders) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...(extraHeaders ?? {}),
  });
  res.end(JSON.stringify(body));
}

function sendRaw(res, out) {
  res.writeHead(out.status, { 'Cache-Control': 'no-store', ...(out.headers ?? {}) });
  res.end(out.body ?? '');
}

function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    let done = false;
    const finish = (v) => { if (!done) { done = true; resolve(v); } };
    req.on('data', (chunk) => {
      data += String(chunk);
      if (data.length > MAX_BODY) { req.destroy(); finish(''); }
    });
    req.on('end', () => finish(data));
    req.on('error', () => finish(data));
  });
}

/* ----------------------------- API dispatcher ----------------------------- */
async function handleApi(req, res, url) {
  const pathname = url.pathname.replace(/\/+$/, '') || '/';
  const method = (req.method || 'GET').toUpperCase();

  try {
    if (pathname === '/api/book-search') {
      if (method !== 'GET') return sendJson(res, 405, { error: 'method_not_allowed' });
      try {
        const payload = await searchBooks(url.searchParams.get('q') ?? '');
        sendJson(res, 200, payload);
      } catch (err) {
        if (err instanceof Error && err.message === 'EMPTY_QUERY') sendJson(res, 400, { error: 'missing_query' });
        else if (err instanceof BookUpstreamError) sendJson(res, 502, { error: 'upstream_unavailable', message: err.message });
        else sendJson(res, 500, { error: 'internal_error' });
      }
      return;
    }

    if (pathname === '/api/admin/login') {
      if (method !== 'POST') return sendJson(res, 405, { error: 'method_not_allowed' });
      const rawBody = await readBody(req);
      const out = await adminLogin({ rawBody, env: process.env });
      sendJson(res, out.status, out.body, out.headers);
      return;
    }

    if (pathname === '/api/up4ever/files') {
      if (method !== 'GET') return sendJson(res, 405, { error: 'method_not_allowed' });
      const cookieHeader = typeof req.headers.cookie === 'string' ? req.headers.cookie : '';
      const out = await up4everFiles({ cookieHeader, env: process.env });
      sendJson(res, out.status, out.body, out.headers);
      return;
    }

    if (pathname === '/api/admin/google/status' || pathname === '/api/admin/google/start' || pathname === '/api/admin/google/callback') {
      if (method !== 'GET') return sendJson(res, 405, { error: 'method_not_allowed' });
      const origin = originFromHeaders(req.headers);
      if (pathname.endsWith('/status')) return sendRaw(res, googleStatus(process.env));
      if (pathname.endsWith('/start')) return sendRaw(res, googleStart({ origin, env: process.env }));
      const query = {};
      for (const [k, v] of url.searchParams) query[k] = v;
      return sendRaw(res, await googleCallback({ query, origin, env: process.env }));
    }

    sendJson(res, 404, { error: 'not_found' });
  } catch {
    sendJson(res, 500, { error: 'internal_error' });
  }
}

/* --------------------------- static + SPA fallback --------------------------- */
async function serveStatic(req, res) {
  const method = (req.method || 'GET').toUpperCase();
  if (method !== 'GET' && method !== 'HEAD') {
    sendJson(res, 405, { error: 'method_not_allowed' });
    return;
  }
  const head = method === 'HEAD';

  let pathname;
  try {
    pathname = decodeURIComponent(req.url.split('?')[0]);
  } catch {
    sendJson(res, 400, { error: 'bad_request' });
    return;
  }

  const rel = path.normalize(pathname).replace(/^(\.\.[/\\])+/, '');
  let filePath = path.join(DIST, rel);
  if (filePath !== DIST && !filePath.startsWith(DIST + path.sep)) filePath = path.join(DIST, '404.html');

  let found = null;
  try {
    const st = await stat(filePath);
    if (st.isFile()) found = { filePath, size: st.size };
  } catch {
    found = null;
  }

  // SPA fallback: extension-less client routes → index.html
  if (!found) {
    if (path.extname(rel)) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end(head ? undefined : 'Not found');
      return;
    }
    filePath = path.join(DIST, 'index.html');
    try {
      const st = await stat(filePath);
      found = { filePath, size: st.size };
    } catch {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end(head ? undefined : 'Build missing: run `npm run build` before `npm start`.');
      return;
    }
  }

  const ext = path.extname(found.filePath).toLowerCase();
  const isHtml = ext === '.html';
  const isHashedAsset = found.filePath.includes(`${path.sep}assets${path.sep}`);
  const cacheControl = isHtml
    ? 'no-cache'
    : isHashedAsset
      ? 'public, max-age=31536000, immutable'
      : 'public, max-age=3600';

  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': found.size,
    'Cache-Control': cacheControl,
  });
  if (head) { res.end(); return; }
  createReadStream(found.filePath).pipe(res);
}

createServer((req, res) => {
  let url;
  try {
    url = new URL(req.url || '/', 'http://internal');
  } catch {
    sendJson(res, 400, { error: 'bad_request' });
    return;
  }
  if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
    void handleApi(req, res, url);
  } else {
    void serveStatic(req, res);
  }
}).listen(PORT, HOST, () => {
  // startup line only — never log env values
  console.log(`ktobati production server: http://${HOST}:${PORT} (dist: ${DIST})`);
});
