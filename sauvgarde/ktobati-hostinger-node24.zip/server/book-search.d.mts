/** A single metadata-only search result (never includes book files). */
export interface BookMetaResult {
  identifier: string;
  title: string;
  author?: string;
  year?: string;
  language?: string;
  isbn?: string;
  description?: string;
  /** cover thumbnail URL (archive.org image service — metadata, not a book file) */
  coverUrl: string;
}

export interface BookMetaSearchResponse {
  source: 'internet_archive';
  results: BookMetaResult[];
}

/** Upstream (archive.org) failed to answer — mapped to HTTP 502. */
export declare class UpstreamError extends Error {
  constructor(message: string);
}

/**
 * Search Internet Archive metadata (public endpoint, no API key).
 * Never downloads or stores book files (PDF/EPUB/…).
 * @throws {Error} `EMPTY_QUERY` for a blank query
 * @throws {UpstreamError} when archive.org is unreachable or answers badly
 */
export declare function searchBooks(query: unknown): Promise<BookMetaSearchResponse>;
