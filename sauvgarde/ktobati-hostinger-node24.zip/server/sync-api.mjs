/**
 * Shared request handlers for the sync API (used by the Vite dev/preview
 * middleware AND the Netlify Functions — identical behaviour everywhere).
 *
 *   POST /api/admin/login     server-only creds (ADMIN_SYNC_*) → HttpOnly session cookie
 *   GET  /api/up4ever/files   cookie-gated account listing (fail closed) + UP4EVER_API_KEY
 *
 * Secrets handled here never appear in responses, URLs, or logs.
 */
import { issueToken, verifyToken, checkCredentials, authConfigured, tokenFromRequest, sessionSetCookie } from './admin-session.mjs';
import { listAccountFiles, Up4everAuthError, Up4everRateError, UpstreamError } from './up4ever.mjs';

const json = (status, body, headers) => ({ status, body, headers: headers ?? {} });

/** POST /api/admin/login — body: {email, password} (raw string). */
export async function adminLogin({ rawBody, env }) {
  if (!authConfigured(env)) {
    // fail closed: sync disabled until server-only credentials are configured
    return json(503, { error: 'auth_not_configured' });
  }
  let submitted;
  try {
    submitted = JSON.parse(typeof rawBody === 'string' && rawBody ? rawBody : '{}');
  } catch {
    return json(400, { error: 'bad_request' });
  }
  if (!checkCredentials(submitted, env)) {
    return json(401, { error: 'invalid_credentials' });
  }
  const token = issueToken(env);
  if (!token) return json(503, { error: 'auth_not_configured' });
  return json(200, { ok: true }, { 'Set-Cookie': sessionSetCookie(token) });
}

/** GET /api/up4ever/files — requires a valid session cookie, then UP4EVER_API_KEY. */
export async function up4everFiles({ cookieHeader, env }) {
  const token = tokenFromRequest(cookieHeader);
  if (!token || !verifyToken(token, env)) {
    // fail closed: account listing is never public
    return json(401, { error: 'unauthorized' });
  }
  const apiKey = env?.UP4EVER_API_KEY;
  if (typeof apiKey !== 'string' || !apiKey.trim()) {
    return json(503, { error: 'missing_api_key' });
  }
  try {
    const { items, stats } = await listAccountFiles({ apiKey: apiKey.trim() });
    return json(200, { ok: true, items, stats });
  } catch (err) {
    if (err instanceof Up4everAuthError) return json(403, { error: 'up4ever_rejected', message: err.message });
    if (err instanceof Up4everRateError) return json(429, { error: 'up4ever_rate_limited', message: err.message });
    if (err instanceof UpstreamError) return json(502, { error: 'up4ever_unavailable', message: err.message });
    return json(500, { error: 'internal_error' });
  }
}
