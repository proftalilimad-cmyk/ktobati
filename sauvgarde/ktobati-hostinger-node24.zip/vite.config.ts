import type { Plugin } from 'vite';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { searchBooks, UpstreamError as BookUpstreamError } from './server/book-search.mjs';
import { adminLogin, up4everFiles, type SyncEnv } from './server/sync-api.mjs';
import { googleStatus, googleStart, googleCallback, originFromHeaders } from './server/google-auth.mjs';

// Local declaration — the project intentionally has no @types/node dependency.
declare const process: { cwd(): string; env: Record<string, string | undefined> };

/* ---- admin API routes (same-origin, server-side) ----
   GET  /api/book-search      Internet Archive metadata search (public metadata only)
   POST /api/admin/login      server-only creds → HttpOnly/Secure/SameSite cookie
   GET  /api/up4ever/files    cookie-gated Up-4ever account listing (fail closed)
   The UP4EVER_API_KEY / ADMIN_SYNC_* values stay server-side: they are read from
   .env.local / process.env and never forwarded to the client in any form. */

interface ApiReq {
  url?: string;
  method?: string;
  headers?: { cookie?: string; [k: string]: unknown };
  on?: (event: string, cb: (...args: any[]) => void) => void;
  destroy?: () => void;
}
interface ApiRes {
  statusCode: number;
  setHeader(name: string, value: string): void;
  end(body: string): void;
}
type ApiNext = () => void;

function sendJson(res: ApiRes, status: number, body: unknown, headers?: Record<string, string>): void {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  if (headers) for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
  res.end(JSON.stringify(body));
}

const METHOD_405 = { error: 'method_not_allowed' } as const;

function sendRaw(res: ApiRes, out: { status: number; headers: Record<string, string>; body: string }): void {
  res.statusCode = out.status;
  res.setHeader('Cache-Control', 'no-store');
  for (const [k, v] of Object.entries(out.headers)) res.setHeader(k, v);
  res.end(out.body);
}

function readBody(req: ApiReq): Promise<string> {
  return new Promise((resolve) => {
    if (typeof req.on !== 'function') return resolve('');
    let data = '';
    let done = false;
    const finish = (v: string) => { if (!done) { done = true; resolve(v); } };
    req.on('data', (chunk: unknown) => {
      data += String(chunk);
      if (data.length > 65536) {
        try { req.destroy?.(); } catch { /* ignore */ }
        finish('');
      }
    });
    req.on('end', () => finish(data));
    req.on('error', () => finish(data));
  });
}

function adminApi(serverEnv: SyncEnv): Plugin {
  const handle = async (req: ApiReq, res: ApiRes, next: ApiNext): Promise<void> => {
    const url = req.url ?? '';
    const pathname = (url.split('?')[0] ?? '').replace(/\/+$/, '');
    const method = (req.method ?? 'GET').toUpperCase();

    try {
      if (pathname === '/api/book-search') {
        if (method !== 'GET') { sendJson(res, 405, METHOD_405); return; }
        try {
          const q = new URL(url, 'http://localhost').searchParams.get('q') ?? '';
          sendJson(res, 200, await searchBooks(q));
        } catch (err) {
          if (err instanceof Error && err.message === 'EMPTY_QUERY') sendJson(res, 400, { error: 'missing_query' });
          else if (err instanceof BookUpstreamError) sendJson(res, 502, { error: 'upstream_unavailable', message: err.message });
          else sendJson(res, 500, { error: 'internal_error' });
        }
        return;
      }

      if (pathname === '/api/admin/login') {
        if (method !== 'POST') { sendJson(res, 405, METHOD_405); return; }
        const rawBody = await readBody(req);
        const out = await adminLogin({ rawBody, env: serverEnv });
        sendJson(res, out.status, out.body, out.headers);
        return;
      }

      if (pathname === '/api/admin/google/status') {
        if (method !== 'GET') { sendJson(res, 405, METHOD_405); return; }
        sendRaw(res, googleStatus(serverEnv));
        return;
      }

      if (pathname === '/api/admin/google/start') {
        if (method !== 'GET') { sendJson(res, 405, METHOD_405); return; }
        sendRaw(res, googleStart({ origin: originFromHeaders((req.headers ?? {}) as Record<string, unknown>), env: serverEnv }));
        return;
      }

      if (pathname === '/api/admin/google/callback') {
        if (method !== 'GET') { sendJson(res, 405, METHOD_405); return; }
        const sp = new URL(url, 'http://localhost').searchParams;
        const query: Record<string, string> = {};
        sp.forEach((v, k) => { query[k] = v; });
        sendRaw(
          res,
          await googleCallback({
            query,
            origin: originFromHeaders((req.headers ?? {}) as Record<string, unknown>),
            env: serverEnv,
          }),
        );
        return;
      }

      if (pathname === '/api/up4ever/files') {
        if (method !== 'GET') { sendJson(res, 405, METHOD_405); return; }
        const cookieHeader = typeof req.headers?.cookie === 'string' ? req.headers.cookie : '';
        const out = await up4everFiles({ cookieHeader, env: serverEnv });
        sendJson(res, out.status, out.body, out.headers);
        return;
      }

      next();
    } catch {
      sendJson(res, 500, { error: 'internal_error' });
    }
  };

  // Localized registration cast (no @types/node needed; no dependencies added).
  const mount = (middlewares: unknown): void => {
    const use = (middlewares as { use: (fn: unknown) => void }).use.bind(middlewares);
    use(handle);
  };

  return {
    name: 'ktobati:admin-api',
    configureServer(server) {
      mount(server.middlewares);
    },
    configurePreviewServer(server) {
      mount(server.middlewares);
    },
  };
}

export default defineConfig(({ mode }) => {
  // Server-side env only: .env / .env.local / .env.[mode].local, overridden by real env.
  const fileEnv = loadEnv(mode, process.cwd(), '');
  const realEnv = process.env ?? {};
  const pick = (k: string): string | undefined => realEnv[k] ?? fileEnv[k];
  const serverEnv: SyncEnv = {
    ADMIN_SYNC_EMAIL: pick('ADMIN_SYNC_EMAIL'),
    ADMIN_SYNC_PASSWORD: pick('ADMIN_SYNC_PASSWORD'),
    UP4EVER_API_KEY: pick('UP4EVER_API_KEY'),
    GOOGLE_CLIENT_ID: pick('GOOGLE_CLIENT_ID'),
    GOOGLE_CLIENT_SECRET: pick('GOOGLE_CLIENT_SECRET'),
  };

  return {
    plugins: [react(), adminApi(serverEnv)],
    server: {
      host: true,
      port: 5173,
      strictPort: false,
      allowedHosts: true,
    },
    preview: {
      host: true,
      allowedHosts: true,
    },
  };
});
