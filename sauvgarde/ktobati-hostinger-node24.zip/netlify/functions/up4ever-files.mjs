/**
 * Netlify Function — GET /api/up4ever/files.
 * Cookie-gated (server-verified HttpOnly session — fail closed), then uses the
 * server-side UP4EVER_API_KEY to list the account's PDF/EPUB files.
 * The key is sent to Up-4ever as a Bearer header only — never in URLs, responses,
 * logs, or browser storage. File bytes are never downloaded.
 */
import { up4everFiles } from '../../server/sync-api.mjs';

export default async function handler(req) {
  const method = req?.httpMethod || req?.method || 'GET';
  if (method !== 'GET') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json; charset=utf-8' }, body: JSON.stringify({ error: 'method_not_allowed' }) };
  }
  const headers = req?.headers ?? {};
  const cookieHeader = headers.cookie || headers.Cookie || '';
  const out = await up4everFiles({ cookieHeader: String(cookieHeader), env: process.env });
  return {
    statusCode: out.status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...out.headers },
    body: JSON.stringify(out.body),
  };
}
