/**
 * Netlify Function — POST /api/admin/login (server-only credentials).
 * Verifies ADMIN_SYNC_EMAIL/ADMIN_SYNC_PASSWORD from the server environment and
 * sets an HttpOnly/Secure/SameSite session cookie for the /api sync routes.
 * Fails closed (503 auth_not_configured) when the env is not configured.
 */
import { adminLogin } from '../../server/sync-api.mjs';

export default async function handler(req) {
  const method = req?.httpMethod || req?.method || 'GET';
  if (method !== 'POST') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json; charset=utf-8' }, body: JSON.stringify({ error: 'method_not_allowed' }) };
  }
  const rawBody = typeof req.body === 'string' ? req.body : '';
  const out = await adminLogin({ rawBody, env: process.env });
  return {
    statusCode: out.status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...out.headers },
    body: JSON.stringify(out.body),
  };
}
