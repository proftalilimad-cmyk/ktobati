/**
 * Netlify Function — Google sign-in routes for the sync login:
 *   GET /api/admin/google/status    → {configured}
 *   GET /api/admin/google/start     → 302 to Google's consent screen
 *   GET /api/admin/google/callback  → 302 back (+ HttpOnly session cookie)
 * Server-only secrets (GOOGLE_CLIENT_ID/SECRET); fail closed when unset.
 */
import { googleStatus, googleStart, googleCallback, originFromHeaders } from '../../server/google-auth.mjs';

export default async function handler(req) {
  const method = req?.httpMethod || req?.method || 'GET';
  if (method !== 'GET') {
    return { statusCode: 405, headers: { 'Content-Type': 'application/json; charset=utf-8' }, body: JSON.stringify({ error: 'method_not_allowed' }) };
  }

  const headers = req?.headers ?? {};
  let pathname = '/api/admin/google/status';
  let search = '';
  try {
    const u = new URL(req?.rawUrl || `https://${headers.host || 'localhost'}${req?.path || pathname}`);
    pathname = u.pathname;
    search = u.search;
  } catch {
    /* keep defaults */
  }

  if (pathname.endsWith('/start')) {
    const out = googleStart({ origin: originFromHeaders(headers), env: process.env });
    return { statusCode: out.status, headers: out.headers, body: out.body };
  }
  if (pathname.endsWith('/callback')) {
    const query = {};
    for (const [k, v] of new URLSearchParams(search)) query[k] = v;
    const out = await googleCallback({ query, origin: originFromHeaders(headers), env: process.env });
    return { statusCode: out.status, headers: out.headers, body: out.body };
  }
  const out = googleStatus(process.env);
  return { statusCode: out.status, headers: out.headers, body: out.body };
}
