/**
 * Netlify Function — same-origin metadata search endpoint.
 *
 *     GET /api/book-search?q=…      (via the redirects in netlify.toml / _redirects)
 *
 * Proxies the Internet Archive public metadata search from the server side.
 * METADATA ONLY: no book PDF/EPUB is ever downloaded or stored.
 */
import { searchBooks, UpstreamError } from '../../server/book-search.mjs';

const json = (statusCode, body) => ({
  statusCode,
  headers: {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  },
  body: JSON.stringify(body),
});

export default async function handler(req) {
  const event = req || {};

  // method check (classic event: httpMethod — fetch-style Request: method)
  const method = event.httpMethod || event.method || 'GET';
  if (method !== 'GET') return json(405, { error: 'method_not_allowed' });

  // query extraction (classic event: queryStringParameters — Request: url)
  let q = '';
  if (typeof event.url === 'string') {
    try {
      q = new URL(event.url, 'http://localhost').searchParams.get('q') ?? '';
    } catch {
      q = '';
    }
  }
  if (!q && event.queryStringParameters) q = event.queryStringParameters.q ?? '';

  try {
    return json(200, await searchBooks(q));
  } catch (err) {
    if (err instanceof Error && err.message === 'EMPTY_QUERY') return json(400, { error: 'missing_query' });
    if (err instanceof UpstreamError) return json(502, { error: 'upstream_unavailable', message: err.message });
    return json(500, { error: 'internal_error' });
  }
}
