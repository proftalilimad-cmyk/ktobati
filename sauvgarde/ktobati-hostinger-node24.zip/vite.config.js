import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { searchBooks, UpstreamError as BookUpstreamError } from './server/book-search.mjs';
import { adminLogin, up4everFiles } from './server/sync-api.mjs';
import { googleStatus, googleStart, googleCallback, originFromHeaders } from './server/google-auth.mjs';
function sendJson(res, status, body, headers) {
    res.statusCode = status;
    res.setHeader('Content-Type', 'application/json; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    if (headers)
        for (const [k, v] of Object.entries(headers))
            res.setHeader(k, v);
    res.end(JSON.stringify(body));
}
const METHOD_405 = { error: 'method_not_allowed' };
function sendRaw(res, out) {
    res.statusCode = out.status;
    res.setHeader('Cache-Control', 'no-store');
    for (const [k, v] of Object.entries(out.headers))
        res.setHeader(k, v);
    res.end(out.body);
}
function readBody(req) {
    return new Promise((resolve) => {
        if (typeof req.on !== 'function')
            return resolve('');
        let data = '';
        let done = false;
        const finish = (v) => { if (!done) {
            done = true;
            resolve(v);
        } };
        req.on('data', (chunk) => {
            data += String(chunk);
            if (data.length > 65536) {
                try {
                    req.destroy?.();
                }
                catch { /* ignore */ }
                finish('');
            }
        });
        req.on('end', () => finish(data));
        req.on('error', () => finish(data));
    });
}
function adminApi(serverEnv) {
    const handle = async (req, res, next) => {
        const url = req.url ?? '';
        const pathname = (url.split('?')[0] ?? '').replace(/\/+$/, '');
        const method = (req.method ?? 'GET').toUpperCase();
        try {
            if (pathname === '/api/book-search') {
                if (method !== 'GET') {
                    sendJson(res, 405, METHOD_405);
                    return;
                }
                try {
                    const q = new URL(url, 'http://localhost').searchParams.get('q') ?? '';
                    sendJson(res, 200, await searchBooks(q));
                }
                catch (err) {
                    if (err instanceof Error && err.message === 'EMPTY_QUERY')
                        sendJson(res, 400, { error: 'missing_query' });
                    else if (err instanceof BookUpstreamError)
                        sendJson(res, 502, { error: 'upstream_unavailable', message: err.message });
                    else
                        sendJson(res, 500, { error: 'internal_error' });
                }
                return;
            }
            if (pathname === '/api/admin/login') {
                if (method !== 'POST') {
                    sendJson(res, 405, METHOD_405);
                    return;
                }
                const rawBody = await readBody(req);
                const out = await adminLogin({ rawBody, env: serverEnv });
                sendJson(res, out.status, out.body, out.headers);
                return;
            }
            if (pathname === '/api/admin/google/status') {
                if (method !== 'GET') {
                    sendJson(res, 405, METHOD_405);
                    return;
                }
                sendRaw(res, googleStatus(serverEnv));
                return;
            }
            if (pathname === '/api/admin/google/start') {
                if (method !== 'GET') {
                    sendJson(res, 405, METHOD_405);
                    return;
                }
                sendRaw(res, googleStart({ origin: originFromHeaders((req.headers ?? {})), env: serverEnv }));
                return;
            }
            if (pathname === '/api/admin/google/callback') {
                if (method !== 'GET') {
                    sendJson(res, 405, METHOD_405);
                    return;
                }
                const sp = new URL(url, 'http://localhost').searchParams;
                const query = {};
                sp.forEach((v, k) => { query[k] = v; });
                sendRaw(res, await googleCallback({
                    query,
                    origin: originFromHeaders((req.headers ?? {})),
                    env: serverEnv,
                }));
                return;
            }
            if (pathname === '/api/up4ever/files') {
                if (method !== 'GET') {
                    sendJson(res, 405, METHOD_405);
                    return;
                }
                const cookieHeader = typeof req.headers?.cookie === 'string' ? req.headers.cookie : '';
                const out = await up4everFiles({ cookieHeader, env: serverEnv });
                sendJson(res, out.status, out.body, out.headers);
                return;
            }
            next();
        }
        catch {
            sendJson(res, 500, { error: 'internal_error' });
        }
    };
    // Localized registration cast (no @types/node needed; no dependencies added).
    const mount = (middlewares) => {
        const use = middlewares.use.bind(middlewares);
        use(handle);
    };
    return {
        name: 'ktobati:admin-api',
        configureServer(server) {
            mount(server.middlewares);
        },
        configurePreviewServer(server) {
            mount(server.middlewares);
        },
    };
}
export default defineConfig(({ mode }) => {
    // Server-side env only: .env / .env.local / .env.[mode].local, overridden by real env.
    const fileEnv = loadEnv(mode, process.cwd(), '');
    const realEnv = process.env ?? {};
    const pick = (k) => realEnv[k] ?? fileEnv[k];
    const serverEnv = {
        ADMIN_SYNC_EMAIL: pick('ADMIN_SYNC_EMAIL'),
        ADMIN_SYNC_PASSWORD: pick('ADMIN_SYNC_PASSWORD'),
        UP4EVER_API_KEY: pick('UP4EVER_API_KEY'),
        GOOGLE_CLIENT_ID: pick('GOOGLE_CLIENT_ID'),
        GOOGLE_CLIENT_SECRET: pick('GOOGLE_CLIENT_SECRET'),
    };
    return {
        plugins: [react(), adminApi(serverEnv)],
        server: {
            host: true,
            port: 5173,
            strictPort: false,
            allowedHosts: true,
        },
        preview: {
            host: true,
            allowedHosts: true,
        },
    };
});
